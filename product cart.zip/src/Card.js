import React from "react";
import { obj } from "./Data";
import './App.css';
import Popup from "./Popup";

class Card extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            obj: obj
        }
    }
    increment(name) {
        this.setState((pervstate) => ({
            obj: pervstate.obj.map((val) => {
                if (val.name == name) {
                    return { ...val, orderedq: val.orderedq + 1 }
                }
                else {
                    return val;
                }
            })
        })
        )
    }
    decrement(name) {
        this.setState((pervstate) => ({
            obj: pervstate.obj.map((val) => {
                if (val.name == name && val.orderedq >= 1)
                    return { ...val, orderedq: val.orderedq - 1 }
            
                else {
                    return val;
                }
            })
        })
        )
        console.log(name)
    }
    
    

    senddatatoheader(name) {
        let count = 0;
        this.setState((prevstate) => ({
            obj: prevstate.obj.map((val) => {
                if (val.name == name && val.orderedq > 0) {
                    return { ...val, Addtocart: 1 }
                }
                else {
                    return val;
                }
            })
        }));
        setTimeout(() => {
            this.state.obj.forEach((data) => {
                if (data.Addtocart > 0) {
                    count++;
                }
            })
            console.log(count)
            this.props.headercount(count);
        })

    }
    render() {
        let html = this.state.obj.map((val) => {
            return (
                <div className="card">
                    <img src={val.img} />
                    <h2>{val.name}</h2>
                    <div><span>Rs.{val.price}</span>||{val.w}kg</div>
                    <div><button onClick={() => this.increment(val.name)}>+</button>||<span>Rs.{val.orderedq * val.price}</span>||<span><button onClick={() => this.decrement(val.name)}>-</button></span>||<span>Rs.{val.orderedq * val.w}.kg</span></div>
                    <div><button onClick={() => this.senddatatoheader(val.name)}>Add To Cart</button></div>
                </div>
            )
        })
        return (
            <div className="cards">
                {html}
                
            </div>
        )
    }
}
export default Card