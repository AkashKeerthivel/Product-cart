import React from "react";

class Header extends React.Component{
    constructor(props){
        super(props);
    }
    
    render(){
        return(
            <div className="header">
                <h2>Header Component</h2>
                <h2>{this.props.headercount}</h2>

            </div>
        )
    }
}
export default Header