import React from "react";
import Card from "./Card";
import Header from "./Header";

    class App extends React.Component {
        constructor(props){
            super(props);
            this.state ={
                headercount : 0
            }
        }
        headercount=(count)=>{
            this.setState({headercount : count})
        }
        
        
        
        render() {
            return (
                <div>
                    <Header headercount = {this.state.headercount} />
                    <Card headercount = {this.headercount}/>
                </div>
            )
        }
    }
export default App