export const obj = [
    {
        name : 'tomato',
        price : 30,
        w : 1,
        img :'https://w7.pngwing.com/pngs/891/45/png-transparent-tomato-juice-pasta-vegetable-fruit-tomato-sliced-tomato-natural-foods-food-tomato-thumbnail.png',
        orderedq : 0,
        Addtocart : 0
    },
    {
        name : 'carrot',
        price : 40,
        w : 1,
        img : 'https://w7.pngwing.com/pngs/143/955/png-transparent-three-carrot-vegetables-carrot-peruvian-cuisine-root-vegetables-fruit-vegetable-carrot-natural-foods-food-recipe-thumbnail.png',
        orderedq : 0,
        Addtocart : 0
    },
    {
        name : 'beans',
        price : 25,
        w : 1,
        img :'https://w7.pngwing.com/pngs/926/977/png-transparent-green-beans-chickpea-vegetable-legume-fruit-peas-vegetable-hq-s-natural-foods-food-nutrition-thumbnail.png',
        orderedq : 0,
        Addtocart : 0
    },
    {
        name : 'brinjal',
        price : 60,
        w : 1,
        img :'https://w7.pngwing.com/pngs/832/980/png-transparent-three-eggplants-illustration-eggplant-jalebi-tomato-urdu-dish-fresh-brinjal-natural-foods-food-fruit-thumbnail.png',
        orderedq : 0,
        Addtocart : 0
    },
    {
        name : 'banana',
        price : 50,
        w : 1,
        img :'https://w7.pngwing.com/pngs/955/492/png-transparent-banana-powder-fruit-cavendish-banana-banana-yellow-banana-fruit-food-image-file-formats-banana-leaves-thumbnail.png',
        orderedq : 0,
        Addtocart : 0
    },
    

]